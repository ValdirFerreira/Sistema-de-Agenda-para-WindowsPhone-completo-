﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Agenda.Model;
using Agenda.DAO;
using Agenda.Controller;

namespace Agenda
{
    public partial class Edicao : PhoneApplicationPage
    {
        public Edicao()
        {
            InitializeComponent();
            CarregarPagina();

        }

        private string parameter;

        public string Parameter
        {
            get { return parameter; }
            set { parameter = value; }
        }

        private int Id;

        public int ID
        {
            get { return Id; }
            set { Id = value; }
        }

        //Alterado
        private void btnAltera_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Alterar();
                MessageBox.Show("Alterado com Sucesso!");
                NavigationService.Navigate(new Uri("/Lista.xaml", UriKind.RelativeOrAbsolute));
            }
            catch (Exception)
            {
                MessageBox.Show("Ocorreu erro na alteração");
            }
        }

        //Excluir
        private void btnExcluir_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Excluir();
                NavigationService.Navigate(new Uri("/Lista.xaml", UriKind.RelativeOrAbsolute));
                MessageBox.Show("Excluido com Sucesso!");
            }
            catch (Exception)
            { MessageBox.Show("Ocorreu erro ao tentar deletar"); }

        }

        //Voltar
        private void btnVoltar_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Lista.xaml", UriKind.RelativeOrAbsolute));
        }

        public void Excluir()
        {
            DataControl controle = new DataControl();
            controle.Remove(RetornaItem());
        }

        public void Alterar()
        {
            DataControl controle = new DataControl();
            controle.Alterar(RetornaItem());
        }

        //preenche entidade e retrna
        public DataItem RetornaItem()
        {
            DataItem Item = new DataItem();

            if (Id != null)
            {
                Item.Id = Id;
                Item.Titulo = titulo.Text;
                Item.Data = data.Text;
                Item.Conteudo = Conteudo.Text;
            }
            return Item;
        }

        // carregar campos 
        public void CarregaCampos(DataItem Item)
        {
            Id = Item.Id;
            titulo.Text = Item.Titulo;
            data.Text = Item.Data;
            Conteudo.Text = Item.Conteudo;
        }

        public void CarregarPagina()
        {
             if (Internal.Parametro != null)
                parameter = Internal.Parametro;

             if (!string.IsNullOrEmpty(parameter))
            {
                DataControl controle = new DataControl();
                DataItem Item = new DataItem();

                string Titulo = parameter;
                Item = controle.SelecionaItem(Titulo);
                if (Item != null)
                    CarregaCampos(Item);
            }

        }

    }
}