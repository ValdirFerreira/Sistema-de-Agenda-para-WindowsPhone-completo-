﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Agenda.DAO;
using Agenda.Model;
using System.Collections.Generic;

namespace Agenda.Controller
{
    public class DataControl
    {
        
        public void CreateDataBase()
        {
            Provider.CreateDataBase();
        }

        public IEnumerable<DataItem> GetDataItem()
        {
            return Provider.GetDataItems();
        }

        internal void Salvar(DataItem Item)
        {
            Provider.Salvar(Item);
        }

        internal void Alterar(DataItem item)
        {
            Provider.Alterar(item);
        }

        internal void Remove(DataItem Item)
        {

            Provider.Remover(Item);
        }

        public DataItem SelecionaItem(string Titulo)
        {
           return Provider.SelecionaItem(Titulo);
        }
    

    }
}
