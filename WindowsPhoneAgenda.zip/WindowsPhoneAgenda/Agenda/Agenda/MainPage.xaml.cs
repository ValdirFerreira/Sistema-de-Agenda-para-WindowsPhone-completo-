﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Agenda.Controller;
using System.ComponentModel;

namespace Agenda
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            Criarbase();
        }

        private void Criarbase()
        {
            DataControl Controle = new DataControl();
            Controle.CreateDataBase();
        }

        private void btnCompromisso_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Lista.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btnCadastro_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Cadastro.xaml", UriKind.RelativeOrAbsolute));
        }

        private void btnSair_Click(object sender, RoutedEventArgs e)
        {
            // base.OnBackKeyPress(new CancelEventArgs(false));
            OnBackKeyPress(new CancelEventArgs(true));
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("Sair do aplicativo?", "Logout", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                base.OnBackKeyPress(e);
            }
            else e.Cancel = true;
        }


    }
}