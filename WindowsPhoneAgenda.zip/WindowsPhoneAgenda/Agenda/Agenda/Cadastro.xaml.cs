﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Agenda.Model;
using Agenda.Controller;

namespace Agenda
{
    public partial class Cadastro : PhoneApplicationPage
    {
        public Cadastro()
        {
            InitializeComponent();
        }

       
       

        private void Voltar_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));
        }

      
        public void Salvar()
        {
            DataControl controle = new DataControl();
            DataItem Item = new DataItem();

            Item.Titulo = titulo.Text;
            Item.Data = data.Text;
            Item.Conteudo = Conteudo.Text;

            controle.Salvar(Item);
        }

        private void btnIncluir_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Salvar();
                MessageBox.Show("Incluido com Sucesso!");
                NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));
            }
            catch (Exception)
            {

                MessageBox.Show("Ocorreu algum erro para salvar!");
            }

        }

        private void btnVoltar_Click_1(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));
        }
           
    }
}