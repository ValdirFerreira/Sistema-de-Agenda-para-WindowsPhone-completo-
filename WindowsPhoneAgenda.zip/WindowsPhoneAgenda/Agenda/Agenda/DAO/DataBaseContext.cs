﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Data.Linq;
using Agenda.Model;

namespace Agenda.DAO
{
    public class DataBaseContext : DataContext
    {
        public static string ConnectionString = "C:/Projetos/WindowsPhoneAgenda/BaseMyDatabase#1.sdf"; 

        private Table<DataItem> _dataItem;

        public Table<DataItem> DataItem
        {
            get
            {

                if (this._dataItem == null)
                    this._dataItem = this.GetTable<DataItem>();

                return  this._dataItem;
            }

        }

        public DataBaseContext(string connectionString)
            : base(connectionString)
        {

        }

    }
}
