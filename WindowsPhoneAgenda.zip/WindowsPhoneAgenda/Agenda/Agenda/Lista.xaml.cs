﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Agenda.Controller;
using Agenda.Model;

namespace Agenda
{
    public partial class Lista : PhoneApplicationPage
    {
        public Lista()
        {
            InitializeComponent();
            CarregarLista();
        }

        private void ListaCompromisso_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ListaCompromisso.SelectedItem != null)
            {
                Uri uri = new Uri("/Edicao.xaml", UriKind.RelativeOrAbsolute);
                Internal.Parametro = ListaCompromisso.SelectedItem.ToString();
                this.NavigationService.Navigate(uri);
            }
        }

        private void Voltar_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/MainPage.xaml", UriKind.RelativeOrAbsolute));
        }

        public void CarregarLista()
        {
            try
            {
                this.ListaCompromisso.Items.Clear();

                DataControl controller = new DataControl();
                List<DataItem> itens = controller.GetDataItem().ToList();
                List<string> Titulo = new List<string>();
                foreach (var ListaItens in itens)
                {
                    Titulo.Add(ListaItens.Titulo);
                }
                ListaCompromisso.ItemsSource = Titulo;
            }
            catch (Exception)
            {
                MessageBox.Show("Ocorreu um Erro");
            }

        }
    }
}